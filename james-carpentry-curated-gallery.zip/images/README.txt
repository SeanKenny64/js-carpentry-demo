JS Carpentry & Build — curated gallery

This package contains 60 selected gallery photographs, the logo, and gallery-manifest.csv.

Installation:
1. Back up or rename the existing images folder in the js-carpentry-demo project.
2. Copy this package's images folder into the root of js-carpentry-demo.
3. Keep gallery-manifest.csv alongside the image files, at images/gallery-manifest.csv.

The manifest has 10 categories. Each category contains 5–7 photographs.
Image files are copied unchanged from the supplied archive. The logo is included as a supporting asset and is not counted among the 60 gallery photographs.

Categories:
- kitchens
- extensions
- bespoke-joinery
- renovations
- roofing
- commercial
- period-restoration
- outdoor
- floors-and-tiling
- doors-and-exteriors

Review note:
The selection is based on visual quality, relevance to the domestic building and renovation focus, variety, and avoiding exact duplicate files. Some photographs show work in progress; the manifest descriptions identify these accordingly.
